import sys
sys.path.append("..")

from ValidateTests import validateTests

validateTests("java")