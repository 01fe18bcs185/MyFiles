import math
import os
import random
import re
import sys

#
# Complete the 'canMigrate' function below.
#
# The function is expected to return a STRING.
# The function accepts following parameters:
#  1. INTEGER N
#  2. 2D_INTEGER_ARRAY drive_contents
#

def canMigrate(N, drive_contents):
    # TODO
    pass

if __name__ == '__main__':
    N = int(input().strip())

    drive_contents = []

    for _ in range(N):
        drive_contents.append(list(map(int, input().rstrip().split())))

    result = canMigrate(N, drive_contents)

    print(result)